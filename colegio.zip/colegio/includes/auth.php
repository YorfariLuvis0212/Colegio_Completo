<?php
require_once 'config.php';

/**
 * Función para autenticar usuarios
 */
function authenticate($email, $password) {
    global $conn;
    
    date_default_timezone_set('America/Bogota');
    
    $stmt = $conn->prepare("SELECT * FROM usuario WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        return ['success' => false, 'message' => 'Usuario no encontrado'];
    }
    
    // Verificar bloqueo solo para este usuario específico
    if ($user['bloqueado_until']) {
        $bloqueado_hasta = new DateTime($user['bloqueado_until']);
        $hora_actual = new DateTime('now', new DateTimeZone('America/Bogota'));
        
        if ($bloqueado_hasta > $hora_actual) {
            return [
                'success' => false,
                'message' => "Tu cuenta está bloqueada hasta: ".$bloqueado_hasta->format('H:i')." (hora Colombia)"
            ];
        } else {
            // Si el bloqueo ya expiró, limpiarlo
            $conn->exec("UPDATE usuario SET bloqueado_until = NULL WHERE id = ".$user['id']);
        }
    }
    
    // Verificación de contraseña
    if ($user['password'] === $password) {
        // Reiniciar intentos fallidos al ingresar correctamente
        $stmt = $conn->prepare("UPDATE usuario SET intentos_fallidos = 0, bloqueado_until = NULL WHERE id = ?");
        $stmt->execute([$user['id']]);
        
        $_SESSION['user'] = $user;
        return ['success' => true, 'user' => $user];
    } else {
        // Incrementar intentos fallidos solo para este usuario
        $intentos = $user['intentos_fallidos'] + 1;
        
        if ($intentos >= 3) {
            $hora_desbloqueo = (new DateTime('now', new DateTimeZone('America/Bogota')))
                ->add(new DateInterval('PT30M'))
                ->format('Y-m-d H:i:s');
            
            $stmt = $conn->prepare("UPDATE usuario SET intentos_fallidos = ?, bloqueado_until = ? WHERE id = ?");
            $stmt->execute([$intentos, $hora_desbloqueo, $user['id']]);
            
            return [
                'success' => false,
                'message' => "Demasiados intentos. Tu cuenta estará bloqueada hasta: ".date('H:i', strtotime($hora_desbloqueo))." (hora Colombia)"
            ];
        } else {
            $stmt = $conn->prepare("UPDATE usuario SET intentos_fallidos = ? WHERE id = ?");
            $stmt->execute([$intentos, $user['id']]);
            
            return [
                'success' => false,
                'message' => "Contraseña incorrecta. Intentos: $intentos/3 (solo para tu cuenta)"
            ];
        }
    }
}

/**
 * Verificar si el usuario está logueado
 */
function isLoggedIn() {
    return isset($_SESSION['user']);
}

/**
 * Obtener información del usuario logueado
 */
function getCurrentUser() {
    return $_SESSION['user'] ?? null;
}

/**
 * Cerrar sesión
 */
function logout() {
    session_unset();
    session_destroy();
}
?>