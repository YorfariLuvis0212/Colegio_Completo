<?php
// Configuración de la base de datos
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'colegio');

// Configurar zona horaria para Colombia
date_default_timezone_set('America/Bogota');

// Iniciar sesión
session_start();

// Conexión a la base de datos
try {
    $conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Configuración compatible con todas las versiones de MySQL
    $conn->exec("SET time_zone = '-05:00'");
    
    // Configuración de aislamiento de transacción (compatible)
    $conn->exec("SET SESSION tx_isolation = 'READ-COMMITTED'");
    
    // Verificación de conexión
    $conn->query("SELECT 1"); // Consulta simple para verificar conexión
    
} catch(PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}
?>