<header>
    <nav>
        <div class="logo">Colegio</div>
        <div class="user-info">
            <span><?php echo htmlspecialchars(getCurrentUser()['email']); ?></span>
            <a href="logout.php" class="btn btn-small">Cerrar Sesión</a>
        </div>
    </nav>
</header>