<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener datos del formulario
    $nombre = trim($_POST['nombre']);
    $apellido = trim($_POST['apellido']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    // Validaciones
    if (empty($nombre)) {
        $errors['nombre'] = 'El nombre es requerido';
    }

    if (empty($apellido)) {
        $errors['apellido'] = 'El apellido es requerido';
    }

    if (empty($email)) {
        $errors['email'] = 'El email es requerido';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'El email no es válido';
    } else {
        // Verificar si el email ya existe
        $stmt = $conn->prepare("SELECT id FROM usuario WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors['email'] = 'Este email ya está registrado';
        }
    }

    if (empty($password)) {
        $errors['password'] = 'La contraseña es requerida';
    } elseif (strlen($password) < 6) {
        $errors['password'] = 'La contraseña debe tener al menos 6 caracteres';
    }

    if ($password !== $confirm_password) {
        $errors['confirm_password'] = 'Las contraseñas no coinciden';
    }

    // Si no hay errores, registrar al usuario
    if (empty($errors)) {
        try {
            // En producción, usar password_hash(): $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $hashed_password = $password; // Solo para desarrollo
            
            $stmt = $conn->prepare("INSERT INTO usuario (nombre, apellido, email, password) VALUES (?, ?, ?, ?)");
            $stmt->execute([$nombre, $apellido, $email, $hashed_password]);
            
            $success = 'Usuario registrado exitosamente. Ahora puedes iniciar sesión.';
        } catch (PDOException $e) {
            $errors['general'] = 'Error al registrar el usuario: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="login-container">
        <h1>Registro de Usuario</h1>
        
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <div class="text-center">
                <a href="login.php" class="btn">Ir a Iniciar Sesión</a>
            </div>
        <?php else: ?>
            <?php if (isset($errors['general'])): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($errors['general']); ?></div>
            <?php endif; ?>
            
            <form method="POST" action="register.php">
                <div class="form-group <?php echo isset($errors['nombre']) ? 'has-error' : ''; ?>">
                    <label for="nombre">Nombre:</label>
                    <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($nombre ?? ''); ?>" required>
                    <?php if (isset($errors['nombre'])): ?>
                        <div class="error-message"><?php echo htmlspecialchars($errors['nombre']); ?></div>
                    <?php endif; ?>
                </div>
                
                <div class="form-group <?php echo isset($errors['apellido']) ? 'has-error' : ''; ?>">
                    <label for="apellido">Apellido:</label>
                    <input type="text" id="apellido" name="apellido" value="<?php echo htmlspecialchars($apellido ?? ''); ?>" required>
                    <?php if (isset($errors['apellido'])): ?>
                        <div class="error-message"><?php echo htmlspecialchars($errors['apellido']); ?></div>
                    <?php endif; ?>
                </div>
                
                <div class="form-group <?php echo isset($errors['email']) ? 'has-error' : ''; ?>">
                    <label for="email">Correo Electrónico:</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email ?? ''); ?>" required>
                    <?php if (isset($errors['email'])): ?>
                        <div class="error-message"><?php echo htmlspecialchars($errors['email']); ?></div>
                    <?php endif; ?>
                </div>
                
                <div class="form-group <?php echo isset($errors['password']) ? 'has-error' : ''; ?>">
    <label for="password">Contraseña:</label>
    <div class="input-with-icon">
        <input type="password" id="password" name="password" class="form-control" required>
        <span class="password-toggle" data-target="password">
            <i class="fas fa-eye"></i>
        </span>
    </div>
    <?php if (isset($errors['password'])): ?>
        <div class="error-message"><?php echo htmlspecialchars($errors['password']); ?></div>
    <?php endif; ?>
</div>

<div class="form-group <?php echo isset($errors['confirm_password']) ? 'has-error' : ''; ?>">
    <label for="confirm_password">Confirmar Contraseña:</label>
    <div class="input-with-icon">
        <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
        <span class="password-toggle" data-target="confirm_password">
            <i class="fas fa-eye"></i>
        </span>
    </div>
    <?php if (isset($errors['confirm_password'])): ?>
        <div class="error-message"><?php echo htmlspecialchars($errors['confirm_password']); ?></div>
    <?php endif; ?>
</div>
                
                <button type="submit" class="btn">Registrarse</button>
            </form>
            
            <div class="text-center" style="margin-top: 20px;">
                <p>¿Ya tienes una cuenta? <a href="login.php">Inicia sesión aquí</a></p>
            </div>
        <?php endif; ?>
    </div>
    
    <script src="assets/js/script.js"></script>
</body>
</html>