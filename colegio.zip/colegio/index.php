<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Colegio - Panel Principal</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container">
    <h1>Bienvenido, <?php echo htmlspecialchars($user['nombre'] . ' ' . $user['apellido']); ?></h1>
        
        <div class="dashboard">
            <!-- Resumen de estudiantes -->
            <div class="card">
                <h2>Estudiantes Activos</h2>
                <?php
                $stmt = $conn->query("SELECT COUNT(*) as total FROM estudiante WHERE estado = 'activo'");
                $count = $stmt->fetch(PDO::FETCH_ASSOC);
                ?>
                <p class="big-number"><?php echo $count['total']; ?></p>
                <a href="estudiantes.php" class="btn">Ver Estudiantes</a>
            </div>
            
            <!-- Resumen de equipos -->
            <div class="card">
                <h2>Equipos Registrados</h2>
                <?php
                $stmt = $conn->query("SELECT COUNT(*) as total FROM equipo");
                $count = $stmt->fetch(PDO::FETCH_ASSOC);
                ?>
                <p class="big-number"><?php echo $count['total']; ?></p>
                <a href="equipos.php" class="btn">Ver Equipos</a>
            </div>
            
            <!-- Resumen de inscripciones -->
            <div class="card">
                <h2>Inscripciones</h2>
                <?php
                $stmt = $conn->query("SELECT COUNT(*) as total FROM inscripcion");
                $count = $stmt->fetch(PDO::FETCH_ASSOC);
                ?>
                <p class="big-number"><?php echo $count['total']; ?></p>
                <a href="inscripciones.php" class="btn">Ver Inscripciones</a>
            </div>
        </div>
        
        <!-- Últimas actividades -->
        <div class="recent-activity">
            <h2>Últimas Actividades</h2>
            <table>
                <thead>
                    <tr>
                        <th>Usuario</th>
                        <th>Acción</th>
                        <th>Descripción</th>
                        <th>Fecha</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $stmt = $conn->query("
                        SELECT a.*, u.email 
                        FROM auditoria a 
                        LEFT JOIN usuario u ON a.usuario_id = u.id 
                        ORDER BY a.fecha DESC 
                        LIMIT 5
                    ");
                    
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['email'] ?? 'Sistema') . "</td>";
                        echo "<td>" . htmlspecialchars($row['accion']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['descripcion']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['fecha']) . "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>