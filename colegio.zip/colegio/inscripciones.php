<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Obtener lista de inscripciones con información de estudiantes
$stmt = $conn->query("
    SELECT i.*, e.nombre, e.apellido 
    FROM inscripcion i
    JOIN estudiante e ON i.estudiante_id = e.id
    ORDER BY i.fecha_inscripcion DESC
");
$inscripciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscripciones - Sistema Escolar</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container">
        <h1>Lista de Inscripciones</h1>
        
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Estudiante</th>
                    <th>Curso</th>
                    <th>Fecha de Inscripción</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($inscripciones as $inscripcion): ?>
                <tr>
                    <td><?php echo htmlspecialchars($inscripcion['id']); ?></td>
                    <td><?php echo htmlspecialchars($inscripcion['nombre'] . ' ' . htmlspecialchars($inscripcion['apellido'])); ?></td>
                    <td><?php echo htmlspecialchars($inscripcion['curso']); ?></td>
                    <td><?php echo htmlspecialchars($inscripcion['fecha_inscripcion']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>