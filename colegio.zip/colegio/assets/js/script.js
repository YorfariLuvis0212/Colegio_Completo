/**
 * Funciones principales para el sistema de gestión escolar
 * Incluye validación de formularios, interacciones y llamadas AJAX
 */

document.addEventListener('DOMContentLoaded', function() {
    // Validación del formulario de login
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            const email = document.getElementById('email');
            const password = document.getElementById('password');
            let isValid = true;

            // Validar email
            if (!email.value || !isValidEmail(email.value)) {
                showError(email, 'Por favor ingrese un correo electrónico válido');
                isValid = false;
            } else {
                clearError(email);
            }

            // Validar contraseña
            if (!password.value || password.value.length < 6) {
                showError(password, 'La contraseña debe tener al menos 6 caracteres');
                isValid = false;
            } else {
                clearError(password);
            }

            if (!isValid) {
                e.preventDefault();
            }
        });
    }

    // Funcionalidad para mostrar/ocultar contraseña
    const togglePassword = document.querySelector('.toggle-password');
    if (togglePassword) {
        togglePassword.addEventListener('click', function() {
            const password = document.getElementById('password');
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
    }

    // Cargar datos del dashboard via AJAX (opcional)
    if (document.querySelector('.dashboard')) {
        loadDashboardStats();
    }

    // Manejar notificaciones
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });
});

/**
 * Funciones de utilidad
 */

// Validar formato de email
function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// Mostrar mensaje de error en un campo
function showError(input, message) {
    const formGroup = input.closest('.form-group');
    let error = formGroup.querySelector('.error-message');
    
    if (!error) {
        error = document.createElement('div');
        error.className = 'error-message';
        formGroup.appendChild(error);
    }
    
    error.textContent = message;
    formGroup.classList.add('has-error');
}

// Limpiar mensaje de error
function clearError(input) {
    const formGroup = input.closest('.form-group');
    const error = formGroup.querySelector('.error-message');
    
    if (error) {
        error.remove();
    }
    
    formGroup.classList.remove('has-error');
}

// Cargar estadísticas del dashboard (AJAX)
function loadDashboardStats() {
    // Podríamos hacer esto via AJAX para datos en tiempo real
    // Pero por ahora usamos los datos renderizados en el servidor
    
    // Ejemplo de cómo sería una llamada AJAX:
    /*
    fetch('/api/dashboard/stats')
        .then(response => response.json())
        .then(data => {
            document.querySelector('.students-count').textContent = data.students;
            document.querySelector('.equipment-count').textContent = data.equipment;
            document.querySelector('.enrollments-count').textContent = data.enrollments;
        })
        .catch(error => console.error('Error loading dashboard stats:', error));
    */
}

// Función para confirmar acciones importantes
function confirmAction(message, callback) {
    if (confirm(message)) {
        callback();
    }
}

// Exportar funciones para uso global (si es necesario)
window.utils = {
    isValidEmail,
    showError,
    clearError,
    confirmAction
};

// Agregar esta función para manejar el toggle de contraseña en el registro
document.addEventListener('DOMContentLoaded', function() {
    // Función para alternar visibilidad de contraseña
    function togglePasswordVisibility() {
        document.querySelectorAll('.password-toggle').forEach(function(toggle) {
            toggle.addEventListener('click', function() {
                const targetId = this.getAttribute('data-target');
                const passwordInput = document.getElementById(targetId);
                const icon = this.querySelector('i');
                
                if (passwordInput.type === 'password') {
                    passwordInput.type = 'text';
                    icon.classList.remove('fa-eye');
                    icon.classList.add('fa-eye-slash');
                } else {
                    passwordInput.type = 'password';
                    icon.classList.remove('fa-eye-slash');
                    icon.classList.add('fa-eye');
                }
            });
        });
    }

    // Inicializar el toggle de contraseña
    togglePasswordVisibility();


    // Validación del formulario de registro
    const registerForm = document.querySelector('form[action="register.php"]');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            const password = document.getElementById('password');
            const confirmPassword = document.getElementById('confirm_password');
            let isValid = true;

            // Validar que las contraseñas coincidan
            if (password.value !== confirmPassword.value) {
                showError(confirmPassword, 'Las contraseñas no coinciden');
                isValid = false;
            } else {
                clearError(confirmPassword);
            }

            if (!isValid) {
                e.preventDefault();
            }
        });
    }
});