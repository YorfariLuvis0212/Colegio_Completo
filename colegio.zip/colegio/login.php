<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    
    $result = authenticate($email, $password);
    
    if ($result['success']) {
        header('Location: index.php');
        exit;
    } else {
        $error = $result['message'];
        
        // Verificar si el usuario está bloqueado
        $stmt = $conn->prepare("SELECT bloqueado_until FROM usuario WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && $user['bloqueado_until'] && strtotime($user['bloqueado_until']) > time()) {
            $error = "Cuenta bloqueada temporalmente. Intente nuevamente después de " . date('H:i', strtotime($user['bloqueado_until']));
        }
    }
}

if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}


?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Colegio - Iniciar Sesión</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="login-container">
        <h1>Sistema de Gestión Escolar</h1>
        <h2>Iniciar Sesión</h2>
        
        <?php if ($error): ?>
    <div class="alert <?php echo strpos($error, 'bloqueada') !== false ? 'alert-warning' : 'alert-danger'; ?>">
        <?php echo htmlspecialchars($error); ?>
    </div>
<?php endif; ?>


        
        <form method="POST" action="login.php">
            <input type="hidden" name="login" value="1">
            
            <div class="form-group">
                <label for="email">Correo Electrónico:</label>
                <input type="email" id="email" name="email" required>
            </div>
            
            <div class="form-group">
                <label for="password">Contraseña:</label>
                <div style="position: relative;">
                    <input type="password" id="password" name="password" required>
                    <i class="toggle-password fas fa-eye" style="position: absolute; right: 10px; top: 35px; cursor: pointer;"></i>
                </div>
            </div>
            
            <button type="submit" class="btn">Ingresar</button>
        </form>
        
        <div class="text-center" style="margin-top: 20px;">
            <p>¿No tienes una cuenta? <a href="register.php">Regístrate aquí</a></p>
        </div>
    </div>
    
    <script src="assets/js/script.js"></script>
</body>
</html>